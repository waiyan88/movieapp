package wy.chris.movieapp;

public class MovieModel {

    public String movieName;
    public String movieImageLink;
    public String movieVideoLink;
    public String movieCategory;
    public String SeriesName;

}
