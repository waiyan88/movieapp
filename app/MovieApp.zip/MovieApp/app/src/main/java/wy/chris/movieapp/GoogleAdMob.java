package wy.chris.movieapp;

public class GoogleAdMob {

    // Real Ads
    /*public static String app_id="ca-app-pub-5906904600998841~7875278918";
    public static  String banner_id="ca-app-pub-5906904600998841/4413695991";
    public static  String interstatial_id="ca-app-pub-5906904600998841/8073739401";
*/

    //Test Ads
    public static String app_id="ca-app-pub-5906904600998841~7875278918";
    public static  String banner_id="ca-app-pub-3940256099942544/6300978111";
    public static  String interstatial_id="ca-app-pub-3940256099942544/1033173712";
}
